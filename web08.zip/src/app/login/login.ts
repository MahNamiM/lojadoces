import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Cliente } from '../model/cliente';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {
  obj: Cliente = new Cliente();
  mensagem: string = "";

  entrar() {
    this.mensagem = "";
    let json = typeof localStorage !== 'undefined' ? localStorage.getItem("cadastro") : null;
    if (json != null) {
      let cadastro: Cliente = JSON.parse(json);
      if (cadastro.email == this.obj.email && cadastro.senha == this.obj.senha) {
        location.href = "./vitrine";
        return;
      }
    }
    this.mensagem = "Email ou senha invalidos.";
  }
}
