import { ItemCesta } from "./item-cesta";
import { Produto } from "./produto";

export class Cesta {
    itens: ItemCesta[] = [];
    valorCesta: number = 0;

    // adiciona o produto; se já existe na cesta, soma a quantidade
    adicionar(produto: Produto): void {
        let item = this.itens.find(i => i.produto.codigo == produto.codigo);
        if (item) {
            item.qtd++;
            item.calcular();
        } else {
            this.itens.push(new ItemCesta(produto));
        }
        this.calcularTotal();
    }

    remover(codigo: number): void {
        this.itens = this.itens.filter(i => i.produto.codigo != codigo);
        this.calcularTotal();
    }

    limpar(): void {
        this.itens = [];
        this.valorCesta = 0;
    }

    calcularTotal(): void {
        this.valorCesta = 0;
        for (let item of this.itens) {
            this.valorCesta += item.valorTotal;
        }
    }
}
