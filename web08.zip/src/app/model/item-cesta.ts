import { Produto } from "./produto";

export class ItemCesta {
    produto: Produto = new Produto();
    qtd: number = 1;
    valorTotal: number = 0;

    constructor(obj?: Produto) {
        if (obj) {
            this.produto = obj;
            this.calcular();
        }
    }

    // usa o valor promocional quando existir
    get valorUnitario(): number {
        return this.produto.valorPromo > 0 ? this.produto.valorPromo : this.produto.valor;
    }

    calcular(): void {
        this.valorTotal = this.qtd * this.valorUnitario;
    }
}
